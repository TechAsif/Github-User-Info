package com.example.githubuserinfo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Repositories extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repositories);

//        LinearLayout linearLayout = findViewById(R.id.acitvity_repositories);
//
//        for(int i=0;i<50;i++){
//
//            TextView textView = new TextView(this);
//            textView.setText(i);
//            linearLayout.addView(textView);
//        }
    }
}
